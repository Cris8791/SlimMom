// src/middleware/authMiddleware.js

import jwt from 'jsonwebtoken';
import User from '../models/userModel.js';  // Asigură-te că importul modelului de utilizator este corect

export const protect = async (req, res, next) => {
  let token;
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
      console.log("Token received:", token);  // Verifică dacă token-ul este recepționat corect
      try {
          const decoded = jwt.verify(token, process.env.JWT_SECRET);
          console.log("Decoded token:", decoded);  // Arată detaliile decodate
          req.user = await User.findById(decoded.userId).select('-password');
          next();
      } catch (error) {
          console.error("Token error: ", error);
          return res.status(401).json({ message: 'Not authorized, token failed' });
      }
  } else {
      console.log("No token found");
      return res.status(401).json({ message: 'Not authorized, no token' });
  }
};

export const admin = (req, res, next) => {
    if (req.user && req.user.isAdmin) {
        next();
    } else {
        res.status(401).json({ message: 'Not authorized as an admin' });
    }
};
